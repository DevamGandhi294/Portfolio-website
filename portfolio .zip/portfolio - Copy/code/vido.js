document.addEventListener("DOMContentLoaded", function() {
  const cards = document.querySelectorAll(".card");

  cards.forEach(card => {
    const video = card.querySelector(".video");

    card.addEventListener("mouseenter", function() {
      if (!video.paused) return; // Check if the video is already playing
      video.play();
    });

    card.addEventListener("mouseleave", function() {
      video.pause();
    });
  });
});
